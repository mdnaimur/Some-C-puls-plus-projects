#include "StdAfx.h"
#include "StartingForm.h"

